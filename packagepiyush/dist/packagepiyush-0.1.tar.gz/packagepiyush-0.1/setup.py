from setuptools import setup
setup(name="packagepiyush",
      version="0.1",
      description="Piyush Package",
      author="Piyush",
      packages=['packagepiyush'],
      install_requires=['datetime', 'random2'])